package mx.edu.utxicotepec.autolavado;

/** @author xLuisCM
 *  @version 26/06/2025 */
public class Autolavado {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
